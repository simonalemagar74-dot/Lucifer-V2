# Changelog

## 0.2.0 - Always listening, screen control, new face (untested first build)
- Always-listening mode as a visible foreground service, with a wake phrase ("Lucifer") by default
  and a 30-minute idle shut-off
- Screen control through an Accessibility service you switch on yourself: read screen, tap, type,
  scroll, back/home/recents, wait; password fields are never typed into
- Confirmation rule for risky taps (send, buy, pay, delete, post, call...) tied to your own words
- Small status dot over other apps while Lucifer is listening, thinking or speaking
- Tool manager with per-group on/off switches and visible permission and risk info
- Speech language setting (Auto, English, Hindi, Nepali); Devanagari replies use a Hindi voice
- New particle-style face with Core, Female and Male looks
- Brain now lives in the app process (LuciferEngine) so it keeps working when other apps are open
- YouTube search opens inside the YouTube app when installed
- Fixed signing key so future updates install over this one
- Listening and speaking now have time limits, so a silent speech service cannot freeze Lucifer
- Safer failure path if Android refuses to start background listening

## 0.1.0 - Version 1 (untested first build)
- Gemini chat with function calling
- Voice input and output
- Phone actions: open app, URL, web search, YouTube search, dialer, alarm, timer
- User-controlled memory
- Unit tests for Gemini JSON parsing and memory serialization

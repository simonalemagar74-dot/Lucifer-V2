# Lucifer release rules. Debug builds do not use this file.
-keepattributes SourceFile,LineNumberTable
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

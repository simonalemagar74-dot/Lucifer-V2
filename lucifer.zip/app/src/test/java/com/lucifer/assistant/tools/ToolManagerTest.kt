package com.lucifer.assistant.tools

import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeGroup(override val id: String, private val fnName: String) : ToolGroup {
    override val title = id
    override val description = "test group"
    override val security = SecurityLevel.LOW
    override val needs = "nothing"

    override fun declarations(): List<JSONObject> = listOf(
        Schema.fn(fnName, "does $fnName", JSONObject().put("a", Schema.str("x")), listOf("a"))
    )

    override suspend fun execute(name: String, args: JSONObject, turn: TurnContext): String = "OK: $name"
}

class ToolManagerTest {
    private val turn = TurnContext("hello", true)

    @Test
    fun enabledGroupsAreOffered() {
        val m = ToolManager(listOf(FakeGroup("a", "tool_a"), FakeGroup("b", "tool_b"))) { emptySet() }
        val fns = m.declarations().getJSONObject(0).getJSONArray("functionDeclarations")
        assertEquals(2, fns.length())
    }

    @Test
    fun disabledGroupIsHiddenAndBlocked() {
        val m = ToolManager(listOf(FakeGroup("a", "tool_a"), FakeGroup("b", "tool_b"))) { setOf("b") }
        val fns = m.declarations().getJSONObject(0).getJSONArray("functionDeclarations")
        assertEquals(1, fns.length())
        assertEquals("OK: tool_a", runBlocking { m.execute("tool_a", JSONObject(), turn) })
        assertTrue(runBlocking { m.execute("tool_b", JSONObject(), turn) }.startsWith("ERROR"))
    }

    @Test
    fun noToolsMeansEmptyDeclarations() {
        val m = ToolManager(listOf(FakeGroup("a", "tool_a"))) { setOf("a") }
        assertEquals(0, m.declarations().length())
    }

    @Test
    fun unknownToolIsAnError() {
        val m = ToolManager(listOf(FakeGroup("a", "tool_a"))) { emptySet() }
        assertTrue(runBlocking { m.execute("nope", JSONObject(), turn) }.startsWith("ERROR"))
    }

    @Test
    fun toolWithNoArgumentsHasNoParameters() {
        val f = Schema.fn("read_screen", "reads")
        assertEquals(false, f.has("parameters"))
    }
}

package com.lucifer.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class WakePhraseTest {
    @Test
    fun commandAfterName() {
        assertEquals("open YouTube", WakePhrase.extract("Lucifer open YouTube"))
    }

    @Test
    fun greetingAndPunctuationAreRemoved() {
        assertEquals("what's the time", WakePhrase.extract("Hey Lucifer, what's the time?"))
        assertEquals("play music", WakePhrase.extract("hello Lusifer play music"))
    }

    @Test
    fun commandBeforeName() {
        assertEquals("open youtube", WakePhrase.extract("open youtube Lucifer"))
    }

    @Test
    fun onlyNameGivesEmptyCommand() {
        assertEquals("", WakePhrase.extract("Lucifer"))
        assertEquals("", WakePhrase.extract("hey lucifer"))
    }

    @Test
    fun otherSpeechIsIgnored() {
        assertNull(WakePhrase.extract("what a nice day"))
        assertNull(WakePhrase.extract(""))
    }

    @Test
    fun devanagariNameWorks() {
        assertEquals("यूट्यूब खोलो", WakePhrase.extract("लूसिफर यूट्यूब खोलो"))
    }
}

package com.lucifer.assistant.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GeminiParserTest {
    private val textReply = """
        {"candidates":[{"content":{"role":"model","parts":[{"text":"Hello there"}]}}]}
    """.trimIndent()

    private val toolReply = """
        {"candidates":[{"content":{"role":"model","parts":[
          {"functionCall":{"name":"open_app","id":"abc123","args":{"app_name":"YouTube"}}}
        ]}}]}
    """.trimIndent()

    @Test
    fun parsesPlainText() {
        val content = GeminiParser.candidateContent(textReply)
        assertNotNull(content)
        assertEquals("Hello there", GeminiParser.text(content!!))
        assertTrue(GeminiParser.toolCalls(content).isEmpty())
    }

    @Test
    fun parsesToolCallWithId() {
        val content = GeminiParser.candidateContent(toolReply)!!
        val calls = GeminiParser.toolCalls(content)
        assertEquals(1, calls.size)
        assertEquals("open_app", calls[0].name)
        assertEquals("abc123", calls[0].id)
        assertEquals("YouTube", calls[0].args.getString("app_name"))
    }

    @Test
    fun emptyCandidatesGivesNull() {
        assertNull(GeminiParser.candidateContent("""{"candidates":[]}"""))
    }

    @Test
    fun extractsErrorMessageAndBlockReason() {
        assertEquals("API key not valid", GeminiParser.errorMessage("""{"error":{"message":"API key not valid"}}"""))
        assertEquals("SAFETY", GeminiParser.blockReason("""{"promptFeedback":{"blockReason":"SAFETY"}}"""))
        assertNull(GeminiParser.errorMessage("not json"))
    }
}

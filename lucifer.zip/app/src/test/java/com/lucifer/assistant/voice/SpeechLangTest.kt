package com.lucifer.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SpeechLangTest {
    @Test
    fun recognizerUsesPhoneDefaultForAuto() {
        assertNull(SpeechLang.recognizerTag("auto"))
        assertEquals("hi-IN", SpeechLang.recognizerTag("hi-IN"))
    }

    @Test
    fun ttsReadsDevanagariWithDevanagariVoice() {
        assertEquals("hi-IN", SpeechLang.ttsTag("नमस्ते", "auto"))
        assertEquals("hi-IN", SpeechLang.ttsTag("नमस्ते", "en-US"))
        assertEquals("ne-NP", SpeechLang.ttsTag("नमस्ते", "ne-NP"))
    }

    @Test
    fun ttsUsesSettingForLatinText() {
        assertNull(SpeechLang.ttsTag("hello", "auto"))
        assertEquals("en-US", SpeechLang.ttsTag("hello", "en-US"))
    }
}

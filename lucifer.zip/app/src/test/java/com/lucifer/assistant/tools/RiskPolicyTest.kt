package com.lucifer.assistant.tools

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RiskPolicyTest {
    @Test
    fun riskyLabelsAreFlagged() {
        assertTrue(RiskPolicy.isRiskyLabel("Send"))
        assertTrue(RiskPolicy.isRiskyLabel("Place order"))
        assertTrue(RiskPolicy.isRiskyLabel("Delete chat"))
        assertTrue(RiskPolicy.isRiskyLabel("Pay now"))
        assertTrue(RiskPolicy.isRiskyLabel("Subscribe"))
        assertTrue(RiskPolicy.isRiskyLabel("Call Mom"))
    }

    @Test
    fun harmlessLabelsAreNotFlagged() {
        assertFalse(RiskPolicy.isRiskyLabel("Search"))
        assertFalse(RiskPolicy.isRiskyLabel("Home"))
        assertFalse(RiskPolicy.isRiskyLabel("Subscribed"))
        assertFalse(RiskPolicy.isRiskyLabel("Orders history"))
        assertFalse(RiskPolicy.isRiskyLabel(null))
    }

    @Test
    fun clearYesIsAffirmative() {
        assertTrue(RiskPolicy.isAffirmative("yes"))
        assertTrue(RiskPolicy.isAffirmative("Yes please"))
        assertTrue(RiskPolicy.isAffirmative("go ahead"))
        assertTrue(RiskPolicy.isAffirmative("do it"))
        assertTrue(RiskPolicy.isAffirmative("हाँ"))
    }

    @Test
    fun anythingElseIsNotAffirmative() {
        assertFalse(RiskPolicy.isAffirmative("no"))
        assertFalse(RiskPolicy.isAffirmative("yes no wait"))
        assertFalse(RiskPolicy.isAffirmative("open YouTube"))
        assertFalse(RiskPolicy.isAffirmative("ok send the message to mom now"))
        assertFalse(RiskPolicy.isAffirmative(""))
    }
}

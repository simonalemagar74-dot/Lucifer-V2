package com.lucifer.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lucifer.assistant.ChatMessage
import com.lucifer.assistant.MessageKind
import com.lucifer.assistant.OrbState
import com.lucifer.assistant.UiState
import com.lucifer.assistant.data.SettingsState

@Composable
fun LuciferScreen(
    ui: UiState,
    settings: SettingsState,
    screenControlOff: Boolean,
    onSend: (String) -> Boolean,
    onFigureTap: () -> Unit,
    onHandsFree: (Boolean) -> Unit,
    onFigureChange: (String) -> Unit,
    onEnableScreenControl: () -> Unit,
    onOpenSettings: () -> Unit
) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val mode = FigureMode.from(settings.figure)

    LaunchedEffect(ui.messages.size) {
        if (ui.messages.isNotEmpty()) listState.animateScrollToItem(ui.messages.size - 1)
    }

    fun submit() {
        if (input.isNotBlank() && onSend(input)) input = ""
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(LuciferColors.BgTop, LuciferColors.BgBottom)))
            .systemBarsPadding()
            .imePadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "LUCIFER",
                    color = LuciferColors.Text,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    letterSpacing = 4.sp
                )
                Text(statusLabel(ui, settings), color = LuciferColors.TextDim, fontSize = 13.sp)
            }
            TextButton(onClick = onOpenSettings) { Text("⚙ Settings", color = LuciferColors.TextDim) }
        }

        if (!imeVisible) {
            val figureHeight = if (ui.messages.size <= 2) 330.dp else 230.dp
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(figureHeight),
                contentAlignment = Alignment.Center
            ) {
                ParticleFigure(
                    state = ui.orb,
                    mode = mode,
                    modifier = Modifier
                        .fillMaxSize()
                        .semantics { contentDescription = figureDescription(ui.orb) }
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = onFigureTap
                        )
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FigureMode.entries.forEach { m ->
                    Pill(m.name, mode == m) { onFigureChange(m.name) }
                    Spacer(Modifier.width(8.dp))
                }
            }
        }

        if (screenControlOff && !imeVisible) {
            Surface(
                color = LuciferColors.Surface,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clickable(onClick = onEnableScreenControl)
            ) {
                Text(
                    "Screen control is off, so I can open apps but not tap or type inside them. Tap here to turn it on.",
                    color = LuciferColors.Amber,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        if (ui.partial.isNotBlank()) {
            Text(
                ui.partial,
                color = LuciferColors.Cyan,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 4.dp),
                textAlign = TextAlign.Center
            )
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(ui.messages, key = { it.id }) { MessageRow(it) }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Switch(checked = ui.handsFree, onCheckedChange = onHandsFree)
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Always listening", color = LuciferColors.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Text(
                    if (settings.requireWakePhrase) "Say \"Lucifer, ...\" any time, even in other apps"
                    else "Reacts to everything it hears",
                    color = LuciferColors.TextDim,
                    fontSize = 12.sp
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message Lucifer") },
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { submit() })
            )
            Spacer(Modifier.width(8.dp))
            if (input.isNotBlank()) {
                Button(onClick = { submit() }) { Text("Send") }
            } else {
                Button(onClick = onFigureTap) { Text(if (ui.orb == OrbState.IDLE) "🎤" else "■") }
            }
        }
    }
}

private fun statusLabel(ui: UiState, settings: SettingsState): String = when (ui.orb) {
    OrbState.IDLE -> if (ui.handsFree) "Listening for \"Lucifer\"" else "Tap my face to talk"
    OrbState.LISTENING ->
        if (ui.handsFree && settings.requireWakePhrase) "Listening for \"Lucifer\"..." else "Listening..."
    OrbState.THINKING -> "Thinking... (tap to cancel)"
    OrbState.SPEAKING -> "Speaking... (tap to stop)"
}

private fun figureDescription(orb: OrbState): String = when (orb) {
    OrbState.IDLE -> "Lucifer. Tap to talk."
    OrbState.LISTENING -> "Lucifer is listening."
    OrbState.THINKING -> "Lucifer is thinking. Tap to cancel."
    OrbState.SPEAKING -> "Lucifer is speaking. Tap to stop."
}

@Composable
private fun MessageRow(m: ChatMessage) {
    when (m.kind) {
        MessageKind.USER -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Bubble(m.text, LuciferColors.UserBubble)
        }
        MessageKind.ASSISTANT -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Bubble(m.text, LuciferColors.Surface)
        }
        MessageKind.TOOL -> Text(
            "⚙ ${m.text}",
            color = LuciferColors.Amber,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
        MessageKind.ERROR -> Text(
            m.text,
            color = MaterialTheme.colorScheme.error,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
    }
}

@Composable
private fun Bubble(text: String, background: Color) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = background,
        modifier = Modifier.widthIn(max = 310.dp)
    ) {
        Text(
            text,
            color = LuciferColors.Text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
        )
    }
}

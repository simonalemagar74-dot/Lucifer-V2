package com.lucifer.assistant.tools

import kotlinx.coroutines.CancellationException
import org.json.JSONArray
import org.json.JSONObject

/**
 * Registry of tool groups. Only groups the user has not switched off are offered to the AI, and
 * only those can run - so a disabled group cannot be used even if the AI asks for it.
 */
class ToolManager(
    private val all: List<ToolGroup>,
    private val disabledIds: () -> Set<String>
) {
    fun groups(): List<ToolGroup> = all

    fun enabledGroups(): List<ToolGroup> {
        val off = disabledIds()
        return all.filter { it.id !in off }
    }

    /** The "tools" array for Gemini. Empty if every group is switched off. */
    fun declarations(): JSONArray {
        val fns = JSONArray()
        enabledGroups().forEach { group -> group.declarations().forEach { fns.put(it) } }
        val out = JSONArray()
        if (fns.length() > 0) out.put(JSONObject().put("functionDeclarations", fns))
        return out
    }

    /** Runs a tool. Never throws (except cancellation); failures come back as "ERROR: ...". */
    suspend fun execute(name: String, args: JSONObject, turn: TurnContext): String {
        val group = enabledGroups().firstOrNull { name in it.functionNames() }
            ?: return "ERROR: the tool \"$name\" is not available or is switched off in Settings."
        return try {
            group.execute(name, args, turn)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            "ERROR: ${e.javaClass.simpleName} while running $name"
        }
    }
}

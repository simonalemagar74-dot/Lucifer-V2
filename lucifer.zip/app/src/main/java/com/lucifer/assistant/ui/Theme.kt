package com.lucifer.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object LuciferColors {
    val BgTop = Color(0xFF0E1224)
    val BgBottom = Color(0xFF05060C)
    val Ember = Color(0xFFFF3B3B)
    val Amber = Color(0xFFFF9A3C)
    val Cyan = Color(0xFF3BD9FF)
    val Blue = Color(0xFF6EA8FF)
    val Rose = Color(0xFFFF6FA8)
    val Surface = Color(0xFF151A2C)
    val PillSelected = Color(0xFF26324F)
    val UserBubble = Color(0xFF1F3355)
    val Text = Color(0xFFECEEF8)
    val TextDim = Color(0xFF93A0BD)
}

@Composable
fun LuciferTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = LuciferColors.Blue,
            onPrimary = Color(0xFF05060C),
            secondary = LuciferColors.Amber,
            background = LuciferColors.BgBottom,
            onBackground = LuciferColors.Text,
            surface = LuciferColors.Surface,
            onSurface = LuciferColors.Text,
            error = Color(0xFFFF6B6B)
        ),
        content = content
    )
}

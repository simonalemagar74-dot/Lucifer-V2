package com.lucifer.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lucifer.assistant.data.SettingsState
import com.lucifer.assistant.memory.MemoryEntry
import com.lucifer.assistant.tools.ToolGroup

@Composable
fun SettingsScreen(
    settings: SettingsState,
    memory: List<MemoryEntry>,
    toolGroups: List<ToolGroup>,
    screenControlOn: Boolean,
    onUpdate: ((SettingsState) -> SettingsState) -> Unit,
    onDeleteMemory: (String) -> Unit,
    onClearMemory: () -> Unit,
    onNewChat: () -> Unit,
    onEnableScreenControl: () -> Unit,
    onClose: () -> Unit
) {
    // Text fields keep their own copy so typing never fights with state updates.
    var apiKey by remember { mutableStateOf(settings.apiKey) }
    var model by remember { mutableStateOf(settings.model) }
    var name by remember { mutableStateOf(settings.userName) }
    var showKey by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LuciferColors.BgBottom)
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Settings",
                color = LuciferColors.Text,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = onClose) { Text("Done") }
        }

        Section("AI brain (Google Gemini)")
        Hint("Get a free key at aistudio.google.com on your phone, then paste it here. It stays on this phone only.")
        OutlinedTextField(
            value = apiKey,
            onValueChange = {
                apiKey = it
                onUpdate { s -> s.copy(apiKey = it) }
            },
            label = { Text("Gemini API key") },
            singleLine = true,
            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide key" else "Show key") }
        OutlinedTextField(
            value = model,
            onValueChange = {
                model = it
                onUpdate { s -> s.copy(model = it) }
            },
            label = { Text("Model name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Hint("If you see \"model not found\", Google retired this name. Check ai.google.dev/gemini-api/docs/models and paste a current one.")

        Section("You")
        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                onUpdate { s -> s.copy(userName = it) }
            },
            label = { Text("Your name (optional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Section("Voice")
        Hint("Language Lucifer listens for and speaks:")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LANGUAGES.forEach { (label, code) ->
                Pill(label, settings.speechLang == code) { onUpdate { s -> s.copy(speechLang = code) } }
            }
        }
        Spacer(Modifier.height(8.dp))
        ToggleRow("Only react when I say \"Lucifer\"", settings.requireWakePhrase) { on ->
            onUpdate { s -> s.copy(requireWakePhrase = on) }
        }
        Hint(
            "In Always listening mode, your phone's speech service turns what it hears into text. " +
                "With this on, anything without the word \"Lucifer\" is thrown away and never sent to the AI. " +
                "Turn it off only if you want Lucifer to answer everything it hears."
        )
        ToggleRow("Also speak answers to typed messages", settings.speakTyped) { on ->
            onUpdate { s -> s.copy(speakTyped = on) }
        }
        Hint("Answers to your voice are always spoken.")

        Section("Screen control")
        Text(
            if (screenControlOn) "Status: ON. Lucifer can read the screen and tap, type and scroll when you ask."
            else "Status: OFF. Lucifer can open apps but cannot tap or type inside them.",
            color = if (screenControlOn) LuciferColors.Cyan else LuciferColors.Amber,
            fontSize = 14.sp
        )
        Hint(
            "Why it needs this: Android only lets an app operate other apps through the Accessibility feature, " +
                "and only after you switch it on yourself. What it allows: reading text on the screen and tapping, typing and scrolling " +
                "- but only when the AI uses it for something you asked. It never types into password fields, " +
                "does nothing in the background on its own, and you can switch it off any time in the same Android screen."
        )
        OutlinedButton(onClick = onEnableScreenControl) {
            Text(if (screenControlOn) "Open Accessibility settings" else "Turn on screen control")
        }
        Hint(
            "If Android says \"Restricted setting\" or the switch is greyed out: open your phone's Settings, Apps, Lucifer, " +
                "tap the three dots at the top right, choose \"Allow restricted settings\", then try again."
        )
        ToggleRow("Ask me before sending, buying, deleting or posting", settings.confirmRisky) { on ->
            onUpdate { s -> s.copy(confirmRisky = on) }
        }
        Hint("Recommended. Lucifer will stop and ask, and only go ahead if you clearly say yes.")

        Section("Tools")
        Hint("Switch off anything you don't want Lucifer to be able to use.")
        toolGroups.forEach { group ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(group.title, color = LuciferColors.Text, fontWeight = FontWeight.Medium)
                    Text(group.description, color = LuciferColors.TextDim, fontSize = 12.sp)
                    Text(
                        "Needs: ${group.needs}  |  Risk: ${group.security.name}",
                        color = LuciferColors.TextDim,
                        fontSize = 11.sp
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = group.id !in settings.disabledTools,
                    onCheckedChange = { on ->
                        onUpdate { s ->
                            s.copy(disabledTools = if (on) s.disabledTools - group.id else s.disabledTools + group.id)
                        }
                    }
                )
            }
        }

        Section("Memory")
        ToggleRow("Let Lucifer remember things", settings.memoryEnabled) { on ->
            onUpdate { s -> s.copy(memoryEnabled = on) }
        }
        Hint("Lucifer saves something only when you ask (\"remember that...\"). Everything saved is listed here and can be deleted.")
        if (memory.isEmpty()) {
            Text("Nothing saved yet.", color = LuciferColors.TextDim)
        } else {
            memory.forEach { entry ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(entry.text, color = LuciferColors.Text, modifier = Modifier.weight(1f))
                    TextButton(onClick = { onDeleteMemory(entry.id) }) { Text("Delete") }
                }
            }
            OutlinedButton(onClick = { confirmClear = true }) { Text("Delete all memory") }
        }

        Section("Conversation")
        OutlinedButton(onClick = { onNewChat(); onClose() }) { Text("Start a new conversation") }

        Section("Privacy")
        Hint(
            "What leaves your phone: the messages you send, your saved memories, the date and time, and - only while screen control is " +
                "used for a task you asked for - the text visible on your screen. All of this goes to Google's Gemini API to get answers. " +
                "Voice is turned into text by your phone's speech service (Google's), which may use the internet. " +
                "Always listening shows a notification while it is on, and the microphone is used only while it is on. " +
                "Lucifer does not use the camera, contacts, messages or location."
        )
        Spacer(Modifier.height(24.dp))
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Delete all memory?") },
            text = { Text("This permanently deletes everything Lucifer has saved about you.") },
            confirmButton = {
                TextButton(onClick = { onClearMemory(); confirmClear = false }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancel") }
            }
        )
    }
}

private val LANGUAGES = listOf("Auto" to "auto", "English" to "en-US", "Hindi" to "hi-IN", "Nepali" to "ne-NP")

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(22.dp))
    Text(title, color = LuciferColors.Amber, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun Hint(text: String) {
    Text(
        text,
        color = LuciferColors.TextDim,
        fontSize = 13.sp,
        modifier = Modifier.padding(vertical = 4.dp)
    )
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = LuciferColors.Text, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

package com.lucifer.assistant.screen

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.lucifer.assistant.LuciferApp
import com.lucifer.assistant.OrbState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Lets Lucifer see and operate other apps - but only after the user switches it on in Android's
 * Accessibility settings, and only when the AI uses a screen tool for something the user asked.
 * It never types into password fields, and it does nothing in the background on its own.
 */
class LuciferAccessibilityService : AccessibilityService() {

    private class Snap(val node: AccessibilityNodeInfo, val label: String, val rect: Rect)

    private val snapshot = ArrayList<Snap>()
    private var overlayScope: CoroutineScope? = null
    private var dot: StatusDot? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        ScreenState.connected.value = true
        showOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Lucifer reads the screen only when asked, so events are ignored.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        if (instance === this) instance = null
        ScreenState.connected.value = false
        hideOverlay()
        snapshot.clear()
    }

    // ---------------------------------------------------------------- reading the screen

    /** A numbered list of what is visible. The numbers are used by [tapIndex]. */
    fun readScreen(): String {
        val root = rootInActiveWindow
            ?: return "ERROR: the screen can't be read right now (it may still be loading, or it is a protected screen). Try wait, then read_screen again."
        snapshot.clear()
        val dm = resources.displayMetrics
        val out = StringBuilder()
        out.append("App: ").append(root.packageName ?: "unknown").append('\n')
        out.append("Screen size: ").append(dm.widthPixels).append('x').append(dm.heightPixels).append('\n')
        collect(root, 0)
        if (snapshot.isEmpty()) {
            out.append("No readable elements. The screen may be a video, a game or a protected screen.")
            return out.toString()
        }
        snapshot.forEachIndexed { i, s ->
            val n = s.node
            val kind = when {
                n.isEditable -> "field"
                n.isClickable -> "tappable"
                else -> "text"
            }
            out.append('[').append(i + 1).append("] ").append(kind).append(" \"")
                .append(s.label.take(MAX_LABEL)).append('"')
            if (n.isChecked) out.append(" (checked)")
            if (n.isScrollable) out.append(" (scrollable)")
            out.append('\n')
        }
        return out.toString().trimEnd()
    }

    private fun collect(node: AccessibilityNodeInfo, depth: Int) {
        if (snapshot.size >= MAX_NODES || depth > MAX_DEPTH) return
        if (node.isVisibleToUser) {
            val label = labelOf(node)
            val interesting = label.isNotEmpty() || node.isClickable || node.isEditable
            if (interesting) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.width() > 0 && rect.height() > 0) {
                    snapshot.add(Snap(node, label.ifEmpty { "(no label)" }, rect))
                }
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collect(child, depth + 1)
            if (snapshot.size >= MAX_NODES) return
        }
    }

    private fun labelOf(node: AccessibilityNodeInfo): String {
        if (node.isPassword) return "password field (hidden)"
        val text = node.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) return text
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (desc.isNotEmpty()) return desc
        if (node.isClickable) return childLabels(node, 0)
        return ""
    }

    /** Joins the text of a few descendants, so a tappable card gets a useful name. */
    private fun childLabels(node: AccessibilityNodeInfo, depth: Int): String {
        if (depth > 3) return ""
        val parts = ArrayList<String>()
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (child.isPassword) continue
            val t = child.text?.toString()?.trim().orEmpty()
            val d = child.contentDescription?.toString()?.trim().orEmpty()
            when {
                t.isNotEmpty() -> parts.add(t)
                d.isNotEmpty() -> parts.add(d)
                else -> {
                    val deeper = childLabels(child, depth + 1)
                    if (deeper.isNotEmpty()) parts.add(deeper)
                }
            }
            if (parts.size >= 4) break
        }
        return parts.joinToString(" | ")
    }

    // ---------------------------------------------------------------- acting on the screen

    fun labelOfIndex(index: Int): String? = snapshot.getOrNull(index - 1)?.label

    /** The label of the smallest visible element under a screen point, or null if none. */
    fun labelAt(x: Int, y: Int): String? {
        val root = rootInActiveWindow ?: return null
        var best: String? = null
        var bestArea = Long.MAX_VALUE
        fun visit(node: AccessibilityNodeInfo, depth: Int) {
            if (depth > MAX_DEPTH) return
            if (node.isVisibleToUser) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.contains(x, y)) {
                    val label = labelOf(node)
                    val area = rect.width().toLong() * rect.height().toLong()
                    if (label.isNotEmpty() && area < bestArea) {
                        bestArea = area
                        best = label
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                visit(child, depth + 1)
            }
        }
        visit(root, 0)
        return best
    }

    /** Taps element number [index] from the latest [readScreen]. */
    fun tapIndex(index: Int): String {
        val snap = snapshot.getOrNull(index - 1)
            ?: return "ERROR: there is no element number $index. Call read_screen again."
        var target: AccessibilityNodeInfo? = snap.node
        var hops = 0
        while (target != null && !target.isClickable && hops < 6) {
            target = target.parent
            hops++
        }
        val clicked = target != null && target.isClickable &&
            target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (clicked) return "OK: tapped [$index] \"${snap.label.take(MAX_LABEL)}\""
        val tapped = tapPoint(snap.rect.centerX(), snap.rect.centerY())
        return if (tapped) "OK: tapped the position of [$index] \"${snap.label.take(MAX_LABEL)}\""
        else "ERROR: could not tap element $index"
    }

    fun tapPoint(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /** Types into the focused text field (or the first one on screen). Never into passwords. */
    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "ERROR: the screen can't be read right now."
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        val target = if (focused != null && focused.isEditable) focused else firstEditable(root, 0)
            ?: return "ERROR: no text field found. Tap a text field first."
        if (target.isPassword) {
            return "ERROR: that is a password field. I never type into password fields; the user must type it."
        }
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        val ok = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return if (ok) "OK: typed the text" else "ERROR: the field did not accept the text"
    }

    private fun firstEditable(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > MAX_DEPTH) return null
        if (node.isEditable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = firstEditable(child, depth + 1)
            if (found != null) return found
        }
        return null
    }

    /** [down] = reveal content further down the page. */
    fun scroll(down: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val startY = dm.heightPixels * (if (down) 0.70f else 0.30f)
        val endY = dm.heightPixels * (if (down) 0.30f else 0.70f)
        val path = Path().apply {
            moveTo(x, startY)
            lineTo(x, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 350L)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun pressKey(key: String): Boolean = when (key.lowercase()) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        else -> false
    }

    // ---------------------------------------------------------------- status dot on top of other apps

    private fun showOverlay() {
        try {
            val density = resources.displayMetrics.density
            val view = StatusDot(this)
            val size = (26 * density).toInt()
            val lp = WindowManager.LayoutParams(
                size,
                size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.END
            lp.x = (14 * density).toInt()
            lp.y = (44 * density).toInt()
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.addView(view, lp)
            dot = view
            view.visibility = View.GONE
            val engine = (application as LuciferApp).engine
            val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
            overlayScope = scope
            scope.launch {
                engine.ui.collect { ui -> view.apply(ui.orb, ui.handsFree) }
            }
        } catch (e: Exception) {
            dot = null
        }
    }

    private fun hideOverlay() {
        overlayScope?.cancel()
        overlayScope = null
        val view = dot
        dot = null
        if (view != null) {
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                wm.removeView(view)
            } catch (e: Exception) {
                // Already gone.
            }
        }
    }

    /** A small coloured dot showing when Lucifer is listening, thinking or speaking. */
    private class StatusDot(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var color = 0xFF6EA8FF.toInt()

        fun apply(orb: OrbState, handsFree: Boolean) {
            visibility = if (handsFree || orb != OrbState.IDLE) View.VISIBLE else View.GONE
            color = when (orb) {
                OrbState.IDLE -> 0xFF6EA8FF.toInt()
                OrbState.LISTENING -> 0xFF3BD9FF.toInt()
                OrbState.THINKING -> 0xFFFF9A3C.toInt()
                OrbState.SPEAKING -> 0xFFFF6FA8.toInt()
            }
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            val r = width / 2f
            paint.color = color
            paint.alpha = 70
            canvas.drawCircle(r, r, r, paint)
            paint.color = color
            paint.alpha = 255
            canvas.drawCircle(r, r, r * 0.5f, paint)
        }
    }

    companion object {
        @Volatile
        var instance: LuciferAccessibilityService? = null

        private const val MAX_NODES = 80
        private const val MAX_DEPTH = 40
        private const val MAX_LABEL = 110
    }
}

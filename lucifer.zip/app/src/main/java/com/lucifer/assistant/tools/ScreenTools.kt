package com.lucifer.assistant.tools

import com.lucifer.assistant.screen.LuciferAccessibilityService
import kotlinx.coroutines.delay
import org.json.JSONObject

/**
 * Operating other apps: read the screen, tap, type, scroll, press back/home.
 * Needs the user to switch on Lucifer in Android's Accessibility settings.
 *
 * Safety: taps on buttons that look like send / buy / pay / delete / post / call... are refused
 * unless the user's own latest message is a clear "yes" (see [RiskPolicy]).
 */
class ScreenTools : ToolGroup {
    override val id = "screen"
    override val title = "Screen control"
    override val description = "Read the screen and tap, type and scroll in other apps, for example to play a YouTube video."
    override val security = SecurityLevel.HIGH
    override val needs = "Accessibility switch (you turn it on in Android settings)"

    override fun declarations(): List<JSONObject> = listOf(
        Schema.fn(
            "read_screen",
            "Read what is on the phone screen right now as a numbered list. Call this before tapping, and again after every tap, scroll or typing, because the screen changes."
        ),
        Schema.fn(
            "tap_element",
            "Tap an element by its number from the latest read_screen.",
            JSONObject()
                .put("index", Schema.int("Element number from read_screen"))
                .put("confirmed", Schema.bool("Set true ONLY after the user clearly said yes to this exact action in their latest message")),
            listOf("index")
        ),
        Schema.fn(
            "tap_at",
            "Tap a screen position in pixels. Use only when an element has no number in read_screen.",
            JSONObject()
                .put("x", Schema.int("Horizontal pixel"))
                .put("y", Schema.int("Vertical pixel"))
                .put("confirmed", Schema.bool("Set true ONLY after the user clearly said yes to this exact action in their latest message")),
            listOf("x", "y")
        ),
        Schema.fn(
            "type_text",
            "Type text into the focused text field (or the first one on screen). Never use for passwords, PINs or one-time codes.",
            JSONObject().put("text", Schema.str("Text to type")),
            listOf("text")
        ),
        Schema.fn(
            "scroll",
            "Scroll the screen to reveal more content.",
            JSONObject().put("direction", Schema.enumStr("down shows content further down the page, up goes back up", listOf("down", "up"))),
            listOf("direction")
        ),
        Schema.fn(
            "press_key",
            "Press a system button.",
            JSONObject().put("key", Schema.enumStr("Which button", listOf("back", "home", "recents", "notifications"))),
            listOf("key")
        ),
        Schema.fn(
            "wait",
            "Wait a few seconds for a page or app to finish loading.",
            JSONObject().put("seconds", Schema.int("1 to 5")),
            listOf("seconds")
        )
    )

    override suspend fun execute(name: String, args: JSONObject, turn: TurnContext): String {
        if (name == "wait") {
            val s = args.optInt("seconds", 2).coerceIn(1, 5)
            delay(s * 1000L)
            return "OK: waited $s seconds"
        }
        val svc = LuciferAccessibilityService.instance
            ?: return "ERROR: Screen control is not switched on. Tell the user to open Lucifer, tap Settings, then Turn on screen control, and enable Lucifer in Android's Accessibility settings."
        return when (name) {
            "read_screen" -> svc.readScreen()
            "tap_element" -> tapElement(svc, args, turn)
            "tap_at" -> tapAt(svc, args, turn)
            "type_text" -> {
                val text = args.optString("text")
                if (text.isEmpty()) "ERROR: no text given" else svc.typeText(text).also { settle() }
            }
            "scroll" -> {
                val down = args.optString("direction") != "up"
                if (svc.scroll(down)) {
                    settle()
                    "OK: scrolled ${if (down) "down" else "up"}"
                } else "ERROR: could not scroll"
            }
            "press_key" -> {
                val key = args.optString("key")
                if (svc.pressKey(key)) {
                    settle()
                    "OK: pressed $key"
                } else "ERROR: could not press \"$key\""
            }
            else -> "ERROR: unknown tool \"$name\""
        }
    }

    private suspend fun tapElement(svc: LuciferAccessibilityService, args: JSONObject, turn: TurnContext): String {
        val index = args.optInt("index", -1)
        if (index < 1) return "ERROR: give the element number from read_screen"
        val label = svc.labelOfIndex(index)
            ?: return "ERROR: there is no element number $index. Call read_screen again."
        blockIfRisky(label, args, turn)?.let { return it }
        return svc.tapIndex(index).also { settle() }
    }

    private suspend fun tapAt(svc: LuciferAccessibilityService, args: JSONObject, turn: TurnContext): String {
        if (!args.has("x") || !args.has("y")) return "ERROR: give both x and y"
        val x = args.optInt("x", -1)
        val y = args.optInt("y", -1)
        if (x < 0 || y < 0) return "ERROR: that position is off the screen"
        val label = svc.labelAt(x, y)
        blockIfRisky(label, args, turn)?.let { return it }
        return if (svc.tapPoint(x, y)) {
            settle()
            "OK: tapped at ($x, $y)"
        } else "ERROR: could not tap there"
    }

    /** Returns an error message if this tap is risky and the user has not clearly said yes. */
    private fun blockIfRisky(label: String?, args: JSONObject, turn: TurnContext): String? {
        if (!turn.confirmRisky || !RiskPolicy.isRiskyLabel(label)) return null
        val claimed = args.optBoolean("confirmed", false)
        if (claimed && RiskPolicy.isAffirmative(turn.userText)) return null
        return "ERROR: CONFIRMATION_REQUIRED. This would press \"${label?.take(60)}\", which may send, post, buy, delete or otherwise change something. " +
            "Do not press it now. Ask the user out loud whether to go ahead. Only if their next message is a clear yes, call this tool again with confirmed=true."
    }

    private suspend fun settle() {
        delay(900)
    }
}

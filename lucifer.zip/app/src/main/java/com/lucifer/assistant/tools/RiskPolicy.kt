package com.lucifer.assistant.tools

/**
 * Safety rules for screen control. Pure logic, unit-tested.
 *
 * - [isRiskyLabel] flags buttons that can send, buy, delete, post or otherwise change something.
 * - [isAffirmative] decides whether what the user just said is a clear "yes". A risky tap only goes
 *   through when the user's latest message is a clear yes, no matter what the AI asks for.
 */
object RiskPolicy {
    private val riskyWords = listOf(
        "send", "post", "publish", "pay", "buy", "purchase", "order", "checkout", "place order",
        "delete", "remove", "uninstall", "install", "erase", "reset", "transfer", "withdraw",
        "confirm", "submit", "subscribe", "donate", "sign out", "log out", "logout", "call",
        "tweet", "share"
    )

    private val riskyRegex = Regex(
        "\\b(" + riskyWords.joinToString("|") { Regex.escape(it) } + ")\\b"
    )

    fun isRiskyLabel(label: String?): Boolean =
        label != null && riskyRegex.containsMatchIn(label.lowercase())

    private val yes = setOf(
        "yes", "yeah", "yep", "yup", "sure", "ok", "okay", "confirm", "confirmed", "proceed",
        "haan", "han", "ha", "हाँ", "हां", "हा", "ठीक", "जी", "हो"
    )

    private val filler = setOf("please", "it", "go", "ahead", "do", "now", "thanks", "thank", "you")

    private val no = setOf(
        "no", "nope", "don't", "dont", "cancel", "stop", "wait", "nahi", "नहीं", "नही", "मत", "रुको"
    )

    fun isAffirmative(text: String): Boolean {
        val words = text.lowercase().split(Regex("[^\\p{L}\\p{M}']+")).filter { it.isNotEmpty() }
        if (words.isEmpty() || words.size > 5) return false
        if (words.any { it in no }) return false
        if (!words.all { it in yes || it in filler }) return false
        val joined = words.joinToString(" ")
        val phrase = joined == "go ahead" || joined == "do it" ||
            joined == "go ahead please" || joined == "do it please"
        return phrase || words.any { it in yes }
    }
}

package com.lucifer.assistant.data

import android.content.Context

/** Everything the user can configure. Kept on this phone only. */
data class SettingsState(
    val apiKey: String = "",
    val model: String = Prefs.DEFAULT_MODEL,
    val userName: String = "",
    val memoryEnabled: Boolean = true,
    val speakTyped: Boolean = false,
    /** If true, always-listening only reacts to speech that contains "Lucifer". */
    val requireWakePhrase: Boolean = true,
    /** "auto" or a language tag such as en-US, hi-IN, ne-NP. */
    val speechLang: String = "auto",
    /** If true, risky taps (send, buy, delete, post...) need the user's spoken yes. */
    val confirmRisky: Boolean = true,
    /** CORE, FEMALE or MALE. */
    val figure: String = "MALE",
    /** Ids of tool groups the user switched off. */
    val disabledTools: Set<String> = emptySet()
)

class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun read(): SettingsState = SettingsState(
        apiKey = sp.getString(K_KEY, "").orEmpty(),
        model = sp.getString(K_MODEL, DEFAULT_MODEL).orEmpty().ifBlank { DEFAULT_MODEL },
        userName = sp.getString(K_NAME, "").orEmpty(),
        memoryEnabled = sp.getBoolean(K_MEMORY, true),
        speakTyped = sp.getBoolean(K_SPEAK_TYPED, false),
        requireWakePhrase = sp.getBoolean(K_WAKE, true),
        speechLang = sp.getString(K_LANG, "auto").orEmpty().ifBlank { "auto" },
        confirmRisky = sp.getBoolean(K_CONFIRM, true),
        figure = sp.getString(K_FIGURE, "MALE").orEmpty().ifBlank { "MALE" },
        disabledTools = sp.getStringSet(K_DISABLED, null)?.toSet() ?: emptySet()
    )

    fun write(s: SettingsState) {
        sp.edit()
            .putString(K_KEY, s.apiKey.trim())
            .putString(K_MODEL, s.model.trim().ifBlank { DEFAULT_MODEL })
            .putString(K_NAME, s.userName.trim())
            .putBoolean(K_MEMORY, s.memoryEnabled)
            .putBoolean(K_SPEAK_TYPED, s.speakTyped)
            .putBoolean(K_WAKE, s.requireWakePhrase)
            .putString(K_LANG, s.speechLang)
            .putBoolean(K_CONFIRM, s.confirmRisky)
            .putString(K_FIGURE, s.figure)
            .putStringSet(K_DISABLED, HashSet(s.disabledTools))
            .apply()
    }

    companion object {
        /** Change this in Settings if Google retires it. */
        const val DEFAULT_MODEL = "gemini-3.5-flash"

        private const val FILE = "lucifer_prefs"
        private const val K_KEY = "api_key"
        private const val K_MODEL = "model"
        private const val K_NAME = "user_name"
        private const val K_MEMORY = "memory_enabled"
        private const val K_SPEAK_TYPED = "speak_typed"
        private const val K_WAKE = "require_wake_phrase"
        private const val K_LANG = "speech_lang"
        private const val K_CONFIRM = "confirm_risky"
        private const val K_FIGURE = "figure"
        private const val K_DISABLED = "disabled_tools"
    }
}

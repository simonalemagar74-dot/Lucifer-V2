package com.lucifer.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Something went wrong while listening.
 * [quiet] = just "nothing heard", not worth showing. [fatal] = retrying will not help.
 */
data class VoiceProblem(val message: String, val quiet: Boolean, val fatal: Boolean = false)

/**
 * Speech input (Android SpeechRecognizer) and speech output (Android TextToSpeech).
 * Must be created and used on the main thread. The microphone is only opened by [startListening],
 * which the app calls after the user granted the permission and chose to listen.
 */
class VoiceManager(context: Context) {
    private val appContext = context.applicationContext

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var utteranceCounter = 0
    private var currentUtterance: String? = null
    private var currentDone: (() -> Unit)? = null

    init {
        tts = TextToSpeech(appContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val r = tts?.setLanguage(Locale.getDefault())
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.US)
                }
            }
        }
    }

    /** Listens for one phrase. [language] is a tag like "hi-IN", or null for the phone's default. */
    fun startListening(
        language: String?,
        onPartial: (String) -> Unit,
        onFinal: (String) -> Unit,
        onProblem: (VoiceProblem) -> Unit
    ) {
        stopListening()
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            onProblem(
                VoiceProblem(
                    "Speech recognition isn't available on this phone. Make sure the Google app is installed and enabled.",
                    quiet = false,
                    fatal = true
                )
            )
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(appContext)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (t.isNotBlank()) onPartial(t)
            }

            override fun onResults(results: Bundle?) {
                val t = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                stopListening()
                if (t.isBlank()) {
                    onProblem(VoiceProblem("I didn't catch that. Try again.", quiet = true))
                } else {
                    onFinal(t)
                }
            }

            override fun onError(error: Int) {
                stopListening()
                onProblem(describe(error))
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        if (!language.isNullOrBlank()) {
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
        }
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            stopListening()
            onProblem(VoiceProblem("Couldn't start listening. Try again.", quiet = false))
        }
    }

    fun stopListening() {
        val r = recognizer
        recognizer = null
        if (r != null) {
            try {
                r.cancel()
                r.destroy()
            } catch (e: Exception) {
                // Already released; nothing to do.
            }
        }
    }

    /**
     * Speaks [text] in [languageTag] (null = phone default), then calls [onFinished] on the main
     * thread - also if speech fails or is stopped with [stopSpeaking].
     */
    fun speak(text: String, languageTag: String?, onFinished: () -> Unit) {
        val engine = tts
        if (engine == null || !ttsReady) {
            onFinished()
            return
        }
        val clean = text.replace(Regex("[*_#`>]"), "").trim().take(MAX_SPEECH_CHARS)
        if (clean.isEmpty()) {
            onFinished()
            return
        }
        if (currentDone != null) finishCurrent()
        if (!languageTag.isNullOrBlank()) {
            val r = engine.setLanguage(Locale.forLanguageTag(languageTag))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine.setLanguage(Locale.getDefault())
            }
        } else {
            engine.setLanguage(Locale.getDefault())
        }
        val id = "lucifer-${utteranceCounter++}"
        currentUtterance = id
        currentDone = onFinished
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                complete(utteranceId)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                complete(utteranceId)
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                complete(utteranceId)
            }

            override fun onStop(utteranceId: String?, interrupted: Boolean) {
                complete(utteranceId)
            }
        })
        val result = engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, id)
        if (result != TextToSpeech.SUCCESS) {
            finishCurrent()
        }
    }

    /** Hops to the main thread, then finishes the utterance if it is still the current one. */
    private fun complete(utteranceId: String?) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            if (utteranceId != null && utteranceId == currentUtterance) finishCurrent()
        }
    }

    private fun finishCurrent() {
        val done = currentDone
        currentDone = null
        currentUtterance = null
        done?.invoke()
    }

    fun stopSpeaking() {
        tts?.stop()
        finishCurrent()
    }

    fun shutdown() {
        stopListening()
        stopSpeaking()
        tts?.shutdown()
        tts = null
    }

    private fun describe(code: Int): VoiceProblem = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH,
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
            VoiceProblem("I didn't hear anything. Try again.", quiet = true)
        SpeechRecognizer.ERROR_CLIENT ->
            VoiceProblem("Listening was cancelled.", quiet = true)
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
            VoiceProblem(
                "Microphone permission is missing. Allow it in your phone's app settings.",
                quiet = false,
                fatal = true
            )
        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            VoiceProblem("Speech recognition needs internet and couldn't connect.", quiet = false)
        SpeechRecognizer.ERROR_AUDIO ->
            VoiceProblem("There was a problem with the microphone.", quiet = false)
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
            VoiceProblem("The speech service is busy. Trying again.", quiet = true)
        else -> VoiceProblem("Speech recognition failed (code $code). Try again.", quiet = false)
    }

    companion object {
        private const val MAX_SPEECH_CHARS = 3500
    }
}

package com.lucifer.assistant.ui

import android.graphics.Paint
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import com.lucifer.assistant.OrbState
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class FigureMode {
    CORE, FEMALE, MALE;

    companion object {
        fun from(name: String): FigureMode = entries.firstOrNull { it.name == name } ?: MALE
    }
}

/** A cloud of points. Coordinates are roughly -1..1, y grows downward. */
private class Cloud(val n: Int) {
    val x = FloatArray(n)
    val y = FloatArray(n)
    val z = FloatArray(n)
    val phase = FloatArray(n)
    val weight = FloatArray(n)
}

private class Pt(val x: Float, val y: Float, val z: Float, val w: Float)

private const val BUCKETS = 5

private fun buildCloud(mode: FigureMode): Cloud {
    val pts = if (mode == FigureMode.CORE) corePoints() else bustPoints(mode)
    val rnd = Random(99)
    val c = Cloud(pts.size)
    for (i in pts.indices) {
        c.x[i] = pts[i].x
        c.y[i] = pts[i].y
        c.z[i] = pts[i].z
        c.weight[i] = pts[i].w
        c.phase[i] = rnd.nextFloat()
    }
    return c
}

/** A glowing sphere of points that slowly turns. */
private fun corePoints(): List<Pt> {
    val out = ArrayList<Pt>()
    val rnd = Random(5)
    val shell = 1500
    val golden = (PI * (3.0 - sqrt(5.0))).toFloat()
    for (i in 0 until shell) {
        val yy = 1f - 2f * (i + 0.5f) / shell
        val r = sqrt(1f - yy * yy)
        val theta = golden * i
        out.add(Pt(cos(theta) * r * 0.62f, yy * 0.62f, sin(theta) * r * 0.62f, 1f))
    }
    for (i in 0 until 600) {
        val u = rnd.nextFloat()
        val radius = 0.62f * Math.cbrt(u.toDouble()).toFloat()
        val yy = rnd.nextFloat() * 2f - 1f
        val theta = rnd.nextFloat() * 2f * PI.toFloat()
        val rr = sqrt(1f - yy * yy)
        out.add(Pt(cos(theta) * rr * radius, yy * radius, sin(theta) * rr * radius, 0.5f))
    }
    return out
}

/** An original head-and-shoulders silhouette made of points. */
private fun bustPoints(mode: FigureMode): List<Pt> {
    val rnd = Random(if (mode == FigureMode.MALE) 11 else 23)
    val out = ArrayList<Pt>()
    fun depth() = (rnd.nextFloat() - 0.5f) * 0.2f

    val cx = 0f
    val cy = -0.36f
    val rx = 0.27f
    val ry = 0.36f

    // Head outline and interior.
    for (i in 0 until 700) {
        val a = rnd.nextFloat() * 2f * PI.toFloat()
        val rf = 0.86f + 0.14f * rnd.nextFloat()
        out.add(Pt(cx + rx * rf * cos(a), cy + ry * rf * sin(a), depth(), 0.9f))
    }
    var placed = 0
    while (placed < 700) {
        val px = (rnd.nextFloat() * 2f - 1f)
        val py = (rnd.nextFloat() * 2f - 1f)
        val d = sqrt(px * px + py * py)
        if (d < 0.86f) {
            out.add(Pt(cx + rx * px, cy + ry * py, depth(), 0.45f + 0.4f * (1f - d)))
            placed++
        }
    }

    // Face details: eyes, nose, mouth.
    fun cluster(px: Float, py: Float, spreadX: Float, spreadY: Float, count: Int) {
        for (i in 0 until count) {
            out.add(
                Pt(
                    px + rnd.nextGaussian().toFloat() * spreadX,
                    py + rnd.nextGaussian().toFloat() * spreadY,
                    depth(),
                    1f
                )
            )
        }
    }
    cluster(-0.10f, -0.42f, 0.022f, 0.010f, 45)
    cluster(0.10f, -0.42f, 0.022f, 0.010f, 45)
    cluster(0f, -0.33f, 0.008f, 0.045f, 35)
    cluster(0f, -0.20f, 0.045f, 0.008f, 55)

    // Neck.
    for (i in 0 until 250) {
        out.add(
            Pt(
                (rnd.nextFloat() * 2f - 1f) * 0.10f,
                -0.02f + rnd.nextFloat() * 0.18f,
                depth(),
                0.5f
            )
        )
    }

    // Shoulders: a body that widens downward and fades out.
    fun halfWidth(y: Float): Float = minOf(0.14f + (minOf(y, 0.45f) - 0.10f) * 1.9f, 0.82f)
    fun fade(y: Float): Float {
        val t = ((y - 0.10f) / 0.72f).coerceIn(0f, 1f)
        return (1f - t) * (1f - t)
    }
    for (i in 0 until 1100) {
        val y = 0.10f + rnd.nextFloat() * 0.72f
        val x = (rnd.nextFloat() * 2f - 1f) * halfWidth(y)
        out.add(Pt(x, y, depth(), 0.15f + 0.65f * fade(y)))
    }
    for (i in 0 until 320) {
        val y = 0.10f + rnd.nextFloat() * 0.72f
        val side = if (rnd.nextBoolean()) 1f else -1f
        out.add(Pt(side * halfWidth(y) + rnd.nextGaussian().toFloat() * 0.01f, y, depth(), 0.9f * fade(y) + 0.1f))
    }

    // Hair.
    if (mode == FigureMode.MALE) {
        for (i in 0 until 450) {
            val a = PI.toFloat() + rnd.nextFloat() * PI.toFloat()
            val rf = 1.0f + 0.14f * rnd.nextFloat()
            out.add(Pt(cx + rx * rf * cos(a), cy + ry * rf * sin(a), depth(), 0.8f))
        }
    } else {
        for (i in 0 until 500) {
            val a = PI.toFloat() * 0.95f + rnd.nextFloat() * PI.toFloat() * 1.1f
            val rf = 1.0f + 0.22f * rnd.nextFloat()
            out.add(Pt(cx + rx * rf * cos(a), cy + ry * rf * sin(a), depth(), 0.8f))
        }
        for (side in intArrayOf(-1, 1)) {
            for (i in 0 until 480) {
                val y = -0.50f + rnd.nextFloat() * 1.05f
                val spread = 0.98f + 0.14f * rnd.nextFloat()
                val x = side * (rx * spread + 0.10f * maxOf(0f, y + 0.10f))
                out.add(Pt(x, y, depth(), if (y > 0.3f) 0.5f * fade(y) + 0.15f else 0.7f))
            }
        }
    }
    return out
}

/**
 * The face of Lucifer: a cloud of glowing points that breathes while idle, ripples inward while
 * listening, sweeps while thinking and pulses outward from the mouth while speaking.
 */
@Composable
fun ParticleFigure(state: OrbState, mode: FigureMode, modifier: Modifier = Modifier) {
    val cloud = remember(mode) { buildCloud(mode) }
    val buffers = remember(cloud) { Array(BUCKETS) { FloatArray(cloud.n * 2) } }
    val counts = remember { IntArray(BUCKETS) }
    val paint = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeCap = Paint.Cap.ROUND
            style = Paint.Style.STROKE
        }
    }
    val time = remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { now -> time.floatValue = (now - start) / 1_000_000_000f }
        }
    }

    val color by animateColorAsState(
        targetValue = when (state) {
            OrbState.IDLE -> LuciferColors.Blue
            OrbState.LISTENING -> LuciferColors.Cyan
            OrbState.THINKING -> LuciferColors.Amber
            OrbState.SPEAKING -> LuciferColors.Rose
        },
        animationSpec = tween(400),
        label = "figureColor"
    )
    val motion by animateFloatAsState(
        targetValue = when (state) {
            OrbState.IDLE -> 0.004f
            OrbState.LISTENING -> 0.007f
            OrbState.THINKING -> 0.009f
            OrbState.SPEAKING -> 0.012f
        },
        animationSpec = tween(400),
        label = "figureMotion"
    )
    val density = LocalDensity.current.density
    val centerY = if (mode == FigureMode.CORE) 0f else -0.22f

    Canvas(modifier = modifier) {
        val t = time.floatValue
        val w = size.width
        val h = size.height
        val scale = h * 0.5f
        val cx = w / 2f
        val cy = h * 0.52f
        val rgb = color.toArgb() and 0x00FFFFFF
        val angle = if (mode == FigureMode.CORE) t * 0.5f else sin(t * 0.4f) * 0.10f
        val cosA = cos(angle)
        val sinA = sin(angle)
        val sweep = (t * 0.85f) % 1f

        for (k in 0 until BUCKETS) counts[k] = 0

        for (i in 0 until cloud.n) {
            val ph = cloud.phase[i]
            val px = cloud.x[i]
            val py = cloud.y[i]
            val pz = cloud.z[i]
            val rotX = px * cosA + pz * sinA
            val rotZ = -px * sinA + pz * cosA
            val jx = sin(t * 1.3f + ph * 6.2832f) * motion
            val jy = cos(t * 1.1f + ph * 5.1f) * motion
            val sx = cx + (rotX + jx) * scale
            val sy = cy + (py + jy) * scale

            var b = cloud.weight[i] * (0.55f + 0.45f * sin(t * 2.2f + ph * 6.2832f))
            if (mode == FigureMode.CORE) {
                b *= 0.45f + 0.55f * ((rotZ + 0.65f) / 1.3f).coerceIn(0f, 1f)
            }
            val dx = px - 0f
            val dy = py - centerY
            val dist = sqrt(dx * dx + dy * dy)
            when (state) {
                OrbState.SPEAKING -> {
                    val d = abs(dist - sweep * 1.1f)
                    if (d < 0.09f) b += (1f - d / 0.09f) * 0.9f
                }
                OrbState.LISTENING -> {
                    val d = abs(dist - (1f - sweep) * 1.1f)
                    if (d < 0.09f) b += (1f - d / 0.09f) * 0.9f
                }
                OrbState.THINKING -> {
                    val d = abs(py - (sweep * 2f - 1f))
                    if (d < 0.12f) b += (1f - d / 0.12f) * 0.8f
                }
                OrbState.IDLE -> {}
            }
            val bucket = (b * BUCKETS).toInt().coerceIn(0, BUCKETS - 1)
            val c = counts[bucket]
            val buf = buffers[bucket]
            buf[c * 2] = sx
            buf[c * 2 + 1] = sy
            counts[bucket] = c + 1
        }

        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            for (k in 0 until BUCKETS) {
                val n = counts[k]
                if (n == 0) continue
                val alpha = 45 + k * 52
                paint.color = (alpha.coerceAtMost(255) shl 24) or rgb
                paint.strokeWidth = density * (1.5f + k * 0.5f)
                nc.drawPoints(buffers[k], 0, n * 2, paint)
            }
        }
    }
}

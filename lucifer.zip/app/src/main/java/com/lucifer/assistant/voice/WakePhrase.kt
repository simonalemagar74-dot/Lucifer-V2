package com.lucifer.assistant.voice

/**
 * Wake-phrase matching for always-listening mode. Android's speech recognizer turns everything it
 * hears into text, and this checks that text for the name "Lucifer". Speech that does not contain
 * the name is simply thrown away and never sent to the AI.
 */
object WakePhrase {
    private val names = listOf(
        "lucifer", "lusifer", "lucipher", "lucifar", "lucifur", "lusifar",
        "लूसिफर", "लुसिफर", "ल्यूसिफर", "ल्युसिफर", "लूसीफर", "लुसीफर"
    )

    private val greetings = setOf("hey", "hi", "hello", "ok", "okay", "yo", "oh", "अरे", "हे", "हेलो")

    /**
     * Returns null if the name is not in [heard]. Otherwise returns the command with the name (and
     * a leading greeting like "hey") removed. The result is empty if only the name was said.
     */
    fun extract(heard: String): String? {
        val lower = heard.lowercase()
        var bestIndex = -1
        var bestLength = 0
        for (name in names) {
            val i = lower.indexOf(name)
            if (i < 0) continue
            if (bestIndex < 0 || i < bestIndex || (i == bestIndex && name.length > bestLength)) {
                bestIndex = i
                bestLength = name.length
            }
        }
        if (bestIndex < 0) return null
        val safeStart = minOf(bestIndex, heard.length)
        val safeEnd = minOf(bestIndex + bestLength, heard.length)
        var before = heard.substring(0, safeStart).trim()
        val after = heard.substring(safeEnd).trim()
        val beforeWords = before.lowercase().split(Regex("[^\\p{L}\\p{M}]+")).filter { it.isNotEmpty() }
        if (beforeWords.all { it in greetings }) before = ""
        return "$before $after".trim().trim(' ', ',', '.', '!', '?', ':', ';', '-', '।')
    }
}

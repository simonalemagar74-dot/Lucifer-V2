package com.lucifer.assistant.tools

import com.lucifer.assistant.memory.MemoryStore
import org.json.JSONObject

/** Lets the AI save and delete memories - only when the user asks, and only if memory is on. */
class MemoryTools(
    private val memory: MemoryStore,
    private val memoryEnabled: () -> Boolean
) : ToolGroup {
    override val id = "memory"
    override val title = "Memory"
    override val description = "Remember or forget things you ask it to. Everything saved is listed in Settings."
    override val security = SecurityLevel.LOW
    override val needs = "Nothing (stored only on this phone)"

    override fun declarations(): List<JSONObject> = listOf(
        Schema.fn(
            "remember",
            "Save one short fact or preference to the user's private memory. Only use this when the user asks you to remember something.",
            JSONObject().put("fact", Schema.str("The fact to remember, as one short sentence")),
            listOf("fact")
        ),
        Schema.fn(
            "forget",
            "Delete saved memories that contain the given text. Only use this when the user asks you to forget something.",
            JSONObject().put("text", Schema.str("Text to match in saved memories")),
            listOf("text")
        )
    )

    override suspend fun execute(name: String, args: JSONObject, turn: TurnContext): String {
        if (!memoryEnabled()) return "ERROR: memory is turned off in Settings"
        return when (name) {
            "remember" ->
                if (memory.add(args.optString("fact")) != null) "OK: saved to memory"
                else "ERROR: nothing to save"
            "forget" -> {
                val n = memory.removeMatching(args.optString("text"))
                if (n > 0) "OK: deleted $n memory item(s)" else "ERROR: no saved memory matches that"
            }
            else -> "ERROR: unknown tool \"$name\""
        }
    }
}

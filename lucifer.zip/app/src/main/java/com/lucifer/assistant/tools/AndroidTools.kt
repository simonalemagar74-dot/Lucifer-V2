package com.lucifer.assistant.tools

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.net.Uri
import android.provider.AlarmClock
import kotlinx.coroutines.delay
import org.json.JSONObject

/**
 * Opening apps and web pages, searching, the dialer, alarms and timers. Everything uses ordinary
 * public Android intents - nothing hidden and nothing that bypasses Android's security.
 */
class AndroidTools(private val context: Context) : ToolGroup {
    override val id = "android"
    override val title = "Apps, web and phone"
    override val description = "Open apps and web pages, search the web or YouTube, open the dialer, set alarms and timers."
    override val security = SecurityLevel.LOW
    override val needs = "Nothing extra (alarms use the Clock app)"

    override fun declarations(): List<JSONObject> = listOf(
        Schema.fn(
            "open_app",
            "Open an installed app by its name, e.g. YouTube, WhatsApp, Camera, Settings.",
            JSONObject().put("app_name", Schema.str("Name of the app as shown on the home screen")),
            listOf("app_name")
        ),
        Schema.fn(
            "open_url",
            "Open a web page (http or https) in the browser.",
            JSONObject().put("url", Schema.str("Full web address")),
            listOf("url")
        ),
        Schema.fn(
            "search_web",
            "Open a Google search for the given text in the browser.",
            JSONObject().put("query", Schema.str("What to search for")),
            listOf("query")
        ),
        Schema.fn(
            "search_youtube",
            "Open YouTube search results for the given text. It does not play anything by itself; use the screen tools to tap a video.",
            JSONObject().put("query", Schema.str("What to search for on YouTube")),
            listOf("query")
        ),
        Schema.fn(
            "dial_number",
            "Open the phone dialer with a number filled in. The user still has to press the call button.",
            JSONObject().put("phone_number", Schema.str("Phone number: digits with optional + ( ) - and spaces")),
            listOf("phone_number")
        ),
        Schema.fn(
            "set_alarm",
            "Set an alarm in the Clock app at a time on the 24-hour clock.",
            JSONObject()
                .put("hour", Schema.int("Hour 0-23"))
                .put("minute", Schema.int("Minute 0-59"))
                .put("label", Schema.str("Short label for the alarm")),
            listOf("hour", "minute")
        ),
        Schema.fn(
            "set_timer",
            "Start a countdown timer in the Clock app.",
            JSONObject()
                .put("seconds", Schema.int("Length of the timer in seconds"))
                .put("label", Schema.str("Short label for the timer")),
            listOf("seconds")
        )
    )

    override suspend fun execute(name: String, args: JSONObject, turn: TurnContext): String {
        val result = when (name) {
            "open_app" -> openApp(args.optString("app_name"))
            "open_url" -> openUrl(args.optString("url"))
            "search_web" -> viewUri(
                "https://www.google.com/search?q=" + Uri.encode(args.optString("query")),
                "a Google search"
            )
            "search_youtube" -> searchYoutube(args.optString("query"))
            "dial_number" -> dial(args.optString("phone_number"))
            "set_alarm" -> setAlarm(args.optInt("hour", -1), args.optInt("minute", -1), args.optString("label"))
            "set_timer" -> setTimer(args.optInt("seconds", -1), args.optString("label"))
            else -> "ERROR: unknown tool \"$name\""
        }
        // Give the other app a moment to appear before the next step looks at the screen.
        if (result.startsWith("OK") && name in SLOW_TOOLS) delay(1500)
        return result
    }

    private fun openApp(requested: String): String {
        val q = requested.trim().lowercase()
        if (q.isEmpty()) return "ERROR: no app name given"
        val pm = context.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        fun label(i: ResolveInfo) = i.loadLabel(pm).toString()
        val match = apps.firstOrNull { label(it).lowercase() == q }
            ?: apps.firstOrNull { label(it).lowercase().contains(q) }
            ?: apps.firstOrNull { label(it).length >= 3 && q.contains(label(it).lowercase()) }
        if (match == null) {
            val names = apps.map { label(it) }.distinct().sorted().take(30).joinToString(", ")
            return "ERROR: no installed app matches \"$requested\". Some installed apps: $names"
        }
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "ERROR: ${label(match)} can't be launched"
        return if (start(launch)) "OK: opened ${label(match)}" else "ERROR: could not open ${label(match)}"
    }

    private fun openUrl(raw: String): String {
        var url = raw.trim()
        if (url.isEmpty()) return "ERROR: no address given"
        if (!url.startsWith("http://", true) && !url.startsWith("https://", true)) url = "https://$url"
        val uri = Uri.parse(url)
        val host = uri.host
        if (host.isNullOrEmpty()) return "ERROR: that is not a valid web address"
        return viewUri(url, host)
    }

    private fun searchYoutube(raw: String): String {
        val query = raw.trim()
        if (query.isEmpty()) return "ERROR: nothing to search for"
        val inApp = Intent(Intent.ACTION_SEARCH)
            .setPackage(YOUTUBE_PACKAGE)
            .putExtra("query", query)
        if (start(inApp)) return "OK: opened YouTube search results for \"$query\""
        return viewUri(
            "https://www.youtube.com/results?search_query=" + Uri.encode(query),
            "YouTube search results"
        )
    }

    private fun viewUri(url: String, what: String): String {
        val ok = start(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return if (ok) "OK: opened $what" else "ERROR: no app could open $what"
    }

    private fun dial(raw: String): String {
        val number = raw.trim()
        if (!PHONE_REGEX.matches(number)) return "ERROR: that is not a valid phone number"
        val ok = start(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)))
        return if (ok) "OK: opened the dialer with $number. The user must press call themselves."
        else "ERROR: no dialer app found"
    }

    private fun setAlarm(hour: Int, minute: Int, label: String): String {
        if (hour !in 0..23 || minute !in 0..59) return "ERROR: invalid time"
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label.take(60))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val time = "%02d:%02d".format(hour, minute)
        return if (start(intent)) "OK: sent an alarm for $time to the Clock app"
        else "ERROR: no Clock app could set the alarm"
    }

    private fun setTimer(seconds: Int, label: String): String {
        if (seconds !in 1..86_400) return "ERROR: a timer must be between 1 second and 24 hours"
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label.take(60))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (start(intent)) "OK: sent a $seconds second timer to the Clock app"
        else "ERROR: no Clock app could set the timer"
    }

    private fun start(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    companion object {
        private const val YOUTUBE_PACKAGE = "com.google.android.youtube"
        private val PHONE_REGEX = Regex("^[+0-9 ()\\-]{3,20}$")
        private val SLOW_TOOLS = setOf("open_app", "open_url", "search_web", "search_youtube")
    }
}

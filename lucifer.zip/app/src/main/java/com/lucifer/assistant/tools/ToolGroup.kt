package com.lucifer.assistant.tools

import org.json.JSONArray
import org.json.JSONObject

enum class SecurityLevel { LOW, MEDIUM, HIGH }

/** What the user said this turn, and whether risky actions need their yes. */
data class TurnContext(val userText: String, val confirmRisky: Boolean)

/**
 * A group of related tools Lucifer can use (for example "screen control"). Each group has
 * metadata the user can see in Settings, and the whole group can be switched off.
 */
interface ToolGroup {
    val id: String
    val title: String
    val description: String
    val security: SecurityLevel

    /** What the user must allow for this group to work, in plain words. */
    val needs: String

    /** Gemini function declarations for every tool in the group. */
    fun declarations(): List<JSONObject>

    /** Runs one tool. Returns text starting with "OK:" or "ERROR:". */
    suspend fun execute(name: String, args: JSONObject, turn: TurnContext): String
}

fun ToolGroup.functionNames(): Set<String> = declarations().map { it.optString("name") }.toSet()

/** Helpers for building Gemini function declarations. */
object Schema {
    fun str(desc: String): JSONObject = JSONObject().put("type", "string").put("description", desc)

    fun int(desc: String): JSONObject = JSONObject().put("type", "integer").put("description", desc)

    fun bool(desc: String): JSONObject = JSONObject().put("type", "boolean").put("description", desc)

    fun enumStr(desc: String, values: List<String>): JSONObject =
        str(desc).put("enum", JSONArray(values))

    /**
     * Gemini rejects an object schema with no properties, so a tool with no arguments is declared
     * without any "parameters" at all.
     */
    fun fn(
        name: String,
        desc: String,
        props: JSONObject = JSONObject(),
        required: List<String> = emptyList()
    ): JSONObject {
        val f = JSONObject().put("name", name).put("description", desc)
        if (props.length() > 0) {
            val params = JSONObject().put("type", "object").put("properties", props)
            if (required.isNotEmpty()) params.put("required", JSONArray(required))
            f.put("parameters", params)
        }
        return f
    }
}

package com.lucifer.assistant

import android.app.Application

/** Holds the one [LuciferEngine] for the whole app process. */
class LuciferApp : Application() {
    lateinit var engine: LuciferEngine
        private set

    override fun onCreate() {
        super.onCreate()
        engine = LuciferEngine(this)
    }
}

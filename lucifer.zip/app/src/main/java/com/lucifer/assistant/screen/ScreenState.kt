package com.lucifer.assistant.screen

import kotlinx.coroutines.flow.MutableStateFlow

/** Whether the user has switched screen control on in Android's Accessibility settings. */
object ScreenState {
    val connected = MutableStateFlow(false)
}

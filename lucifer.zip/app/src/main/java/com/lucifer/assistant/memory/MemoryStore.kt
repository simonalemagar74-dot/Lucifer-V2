package com.lucifer.assistant.memory

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class MemoryEntry(
    val id: String,
    val text: String,
    val createdAt: Long
)

/**
 * Things the user asked Lucifer to remember. Stored only on this phone, fully visible and
 * deletable in Settings. Nothing is saved unless the AI calls the "remember" tool.
 */
class MemoryStore(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private val _entries = MutableStateFlow(load())
    val entries: StateFlow<List<MemoryEntry>> = _entries.asStateFlow()

    fun add(text: String): MemoryEntry? {
        val clean = text.trim().take(MAX_TEXT)
        if (clean.isEmpty()) return null
        val existing = _entries.value.firstOrNull { it.text.equals(clean, ignoreCase = true) }
        if (existing != null) return existing
        val entry = MemoryEntry(UUID.randomUUID().toString(), clean, System.currentTimeMillis())
        update((_entries.value + entry).takeLast(MAX_ENTRIES))
        return entry
    }

    fun remove(id: String) {
        update(_entries.value.filterNot { it.id == id })
    }

    /** Removes every entry whose text contains [query]. Returns how many were removed. */
    fun removeMatching(query: String): Int {
        val q = query.trim()
        if (q.isEmpty()) return 0
        val keep = _entries.value.filterNot { it.text.contains(q, ignoreCase = true) }
        val removed = _entries.value.size - keep.size
        if (removed > 0) update(keep)
        return removed
    }

    fun clear() {
        update(emptyList())
    }

    private fun update(list: List<MemoryEntry>) {
        _entries.value = list
        sp.edit().putString(K_ENTRIES, toJson(list)).apply()
    }

    private fun load(): List<MemoryEntry> {
        val raw = sp.getString(K_ENTRIES, null) ?: return emptyList()
        return try {
            fromJson(raw)
        } catch (e: Exception) {
            // Corrupted data: keep a copy instead of silently destroying it.
            sp.edit().putString(K_CORRUPT_BACKUP, raw).apply()
            emptyList()
        }
    }

    companion object {
        private const val FILE = "lucifer_memory"
        private const val K_ENTRIES = "entries"
        private const val K_CORRUPT_BACKUP = "entries_corrupt_backup"
        private const val MAX_ENTRIES = 200
        private const val MAX_TEXT = 500

        fun toJson(list: List<MemoryEntry>): String {
            val arr = JSONArray()
            list.forEach {
                arr.put(
                    JSONObject()
                        .put("id", it.id)
                        .put("text", it.text)
                        .put("createdAt", it.createdAt)
                )
            }
            return arr.toString()
        }

        fun fromJson(raw: String): List<MemoryEntry> {
            val arr = JSONArray(raw)
            val out = ArrayList<MemoryEntry>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(MemoryEntry(o.getString("id"), o.getString("text"), o.optLong("createdAt")))
            }
            return out
        }
    }
}

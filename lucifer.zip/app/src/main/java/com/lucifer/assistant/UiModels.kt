package com.lucifer.assistant

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

enum class MessageKind { USER, ASSISTANT, TOOL, ERROR }

data class ChatMessage(val id: Long, val kind: MessageKind, val text: String)

data class UiState(
    val messages: List<ChatMessage> = emptyList(),
    val orb: OrbState = OrbState.IDLE,
    /** Live words while the user is speaking. */
    val partial: String = "",
    /** True while always-listening mode is on. */
    val handsFree: Boolean = false
)

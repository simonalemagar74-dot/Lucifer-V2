package com.lucifer.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lucifer.assistant.screen.ScreenState
import com.lucifer.assistant.ui.LuciferScreen
import com.lucifer.assistant.ui.LuciferTheme
import com.lucifer.assistant.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val engine = (application as LuciferApp).engine
        setContent {
            LuciferTheme {
                LuciferRoot(engine)
            }
        }
    }
}

private fun isGranted(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

@Composable
private fun LuciferRoot(engine: LuciferEngine) {
    val ui by engine.ui.collectAsStateWithLifecycle()
    val settings by engine.settings.collectAsStateWithLifecycle()
    val memory by engine.memory.entries.collectAsStateWithLifecycle()
    val screenOn by ScreenState.connected.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var showSettings by rememberSaveable { mutableStateOf(false) }
    var showScreenDialog by rememberSaveable { mutableStateOf(false) }
    var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        val action = pendingAction
        pendingAction = null
        if (isGranted(context, Manifest.permission.RECORD_AUDIO)) action?.invoke() else engine.onMicDenied()
    }

    /** Runs [action] once the microphone (and, if asked, notification) permission is sorted out. */
    fun withPermissions(needNotifications: Boolean, action: () -> Unit) {
        val missing = ArrayList<String>()
        if (!isGranted(context, Manifest.permission.RECORD_AUDIO)) missing.add(Manifest.permission.RECORD_AUDIO)
        if (needNotifications && Build.VERSION.SDK_INT >= 33 &&
            !isGranted(context, Manifest.permission.POST_NOTIFICATIONS)
        ) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (missing.isEmpty()) {
            action()
        } else {
            pendingAction = action
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    fun onFigureTap() {
        if (ui.orb == OrbState.IDLE && !ui.handsFree) {
            withPermissions(false) { engine.listenOnceAndProcess() }
        } else {
            engine.onFigureTapped()
        }
    }

    fun onHandsFree(on: Boolean) {
        if (on) {
            withPermissions(true) { HandsFreeService.start(context) }
        } else {
            HandsFreeService.stop(context)
            engine.setHandsFree(false)
        }
    }

    BackHandler(enabled = showSettings) { showSettings = false }

    if (showSettings) {
        SettingsScreen(
            settings = settings,
            memory = memory,
            toolGroups = engine.toolGroups,
            screenControlOn = screenOn,
            onUpdate = engine::updateSettings,
            onDeleteMemory = engine::deleteMemory,
            onClearMemory = engine::clearMemory,
            onNewChat = engine::newChat,
            onEnableScreenControl = { showScreenDialog = true },
            onClose = { showSettings = false }
        )
    } else {
        LuciferScreen(
            ui = ui,
            settings = settings,
            screenControlOff = !screenOn && "screen" !in settings.disabledTools,
            onSend = engine::send,
            onFigureTap = { onFigureTap() },
            onHandsFree = { onHandsFree(it) },
            onFigureChange = { name -> engine.updateSettings { s -> s.copy(figure = name) } },
            onEnableScreenControl = { showScreenDialog = true },
            onOpenSettings = { showSettings = true }
        )
    }

    if (showScreenDialog) {
        AlertDialog(
            onDismissRequest = { showScreenDialog = false },
            title = { Text("Turn on screen control") },
            text = {
                Text(
                    "Android will open its Accessibility settings. Find \"Lucifer\" in the list, open it and switch it on.\n\n" +
                        "This lets Lucifer read the screen and tap, type and scroll in other apps, only when you ask it to. " +
                        "It never types into password fields, and you can switch it off any time in the same place.\n\n" +
                        "If the switch is greyed out: Settings, Apps, Lucifer, three dots at the top right, \"Allow restricted settings\"."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showScreenDialog = false
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }) { Text("Open Accessibility settings") }
            },
            dismissButton = {
                TextButton(onClick = { showScreenDialog = false }) { Text("Not now") }
            }
        )
    }
}

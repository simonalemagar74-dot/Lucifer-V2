package com.lucifer.assistant.voice

/** Picks speech languages. Pure logic, unit-tested. */
object SpeechLang {
    /** Language tag for the recognizer, or null to use the phone's default. */
    fun recognizerTag(setting: String): String? = if (setting == "auto") null else setting

    /**
     * Language tag for text-to-speech, or null to use the phone's default.
     * Devanagari text (Hindi/Nepali) is always read with a Devanagari voice.
     */
    fun ttsTag(text: String, setting: String): String? {
        val hasDevanagari = text.any { it.code in 0x0900..0x097F }
        return when {
            hasDevanagari -> if (setting == "ne-NP") "ne-NP" else "hi-IN"
            setting == "auto" -> null
            else -> setting
        }
    }
}

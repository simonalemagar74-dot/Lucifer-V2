# Lucifer (version 0.2.0)

A personal AI assistant for Android. Talk or type; Lucifer answers (and speaks) using Google Gemini
and can open apps, search, set alarms, remember things you ask it to, and operate other apps on your
screen when you allow it.

## Honest status

Written, but **not compiled or run by its author**: the build environment had no Android SDK.
The first GitHub build may reveal small errors. Unit tests exist for the pure logic (wake phrase,
safety rules, tool manager, language choice, Gemini JSON, memory JSON) but have **not been run yet**
either; the GitHub build runs them. Nothing below is claimed as "working" until you have tried it
on your phone.

## What it does (by design)
- Chat with Gemini using your own free API key (stored only on your phone)
- Voice in and voice out (Android speech recognition and text-to-speech), Auto / English / Hindi / Nepali
- **Always listening** (optional): a visible foreground service keeps Lucifer listening while other
  apps are open. By default it only reacts when it hears "Lucifer"; everything else is discarded.
- **Screen control** (optional, you switch it on in Android's Accessibility settings): read the screen,
  tap, type, scroll, press back/home. Never types into password fields. Asks before send / buy / pay /
  delete / post / call buttons, and only proceeds if your own latest message is a clear "yes".
- Open apps, web pages, searches, YouTube search, dialer, alarms and timers
- Memory only when you ask; view, delete, clear and disable in Settings
- Tool manager: every tool group can be switched off in Settings
- New particle-style face (Core / Female / Male) that reacts to listening, thinking and speaking

## What does NOT exist yet
Camera and OCR, PDF reading, weather and location, a true on-device wake-word engine, Code Lab,
plugins, Security Lab, backup and restore, structured logs and diagnostics screen. The AI key is
kept on the phone (not on a backend server as the master prompt prefers) because this is a
personal, phone-only build.

## Known limitations
- Always listening uses Android's speech recognizer, restarted in a loop. It is not a low-power
  wake-word engine: it uses battery, needs internet for most phones, and some phones play a small
  sound each time it restarts. It stops itself after 30 minutes without a command.
- Phone makers (Xiaomi/Redmi, Oppo, Vivo, Samsung...) may kill background apps. Set Lucifer's battery
  option to "No restrictions" / "Unrestricted" if listening stops.
- Screen control only sees what apps expose. Protected screens, games and some video players show
  little or nothing. The confirmation check depends on button names, so an unlabeled button can slip
  through; keep "Ask me before..." on.
- Android 13+ blocks Accessibility for apps installed outside the Play Store until you choose
  "Allow restricted settings" in the app's info page.
- Gemini model names change; if you see "model not found", update the model name in Settings.
- The APK is signed with a fixed personal **debug** key stored in this project, so updates install
  over each other. It is not a production release key.

## Permissions
Internet, Microphone (asked when you first listen), Notifications (for the listening notice),
Foreground service (microphone), Set alarm, and the Accessibility service (you enable it yourself).

## Project layout
- `LuciferEngine.kt` the brain host: listening loop, wake phrase, AI calls, state
- `HandsFreeService.kt` the visible foreground service for always-listening
- `ai/` Gemini client and the assistant loop (replaceable provider)
- `tools/` tool groups (Android, Memory, Screen), tool manager, safety policy
- `screen/` the Accessibility service and the status dot shown over other apps
- `voice/` speech recognition, text-to-speech, wake phrase, language choice
- `memory/` local memory store
- `ui/` Compose screens and the particle face

## Build
GitHub Actions builds the APK (see `.github/workflows/build.yml`). Locally: open in Android Studio
or run `gradle assembleDebug` and `gradle testDebugUnitTest`.
